# IEEE Access Overleaf Submission Package
## Scale-Adaptive Document Conditioning and Attention-Guided Sequence Recognition for Cross-Domain Offline Handwritten Text Recognition

**Author**: A. Venkata Balaji (Registration No: 23BCE20336)  
**Affiliation**: School of Computer Science and Engineering, Vellore Institute of Technology (VIT), India  
**Target Venue**: IEEE Access  

### How to Compile on Overleaf:
1. Open [Overleaf](https://www.overleaf.com/).
2. Click **New Project** -> **Upload Project**.
3. Select this `overleaf_ieee_access_package.zip` file.
4. Set compiler to **pdfLaTeX** (default) with `main.tex` as the root document.
5. Click **Recompile**.
