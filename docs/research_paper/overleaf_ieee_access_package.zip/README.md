# IEEE Access LaTeX Overleaf Package
This package contains the complete, self-contained IEEE Access manuscript for:
"Handwritten Text Recognition using Vision Transformers"
Author: A. Venkata Balaji
Affiliation: School of Computer Science and Engineering, Vellore Institute of Technology, Amaravati, Andhra Pradesh, India

## How to Compile on Overleaf:
1. Upload this zip file directly into Overleaf (New Project -> Upload Project).
2. Overleaf will automatically detect `main.tex` (or select `paper_ieee_access.tex`) as the root document.
3. Ensure compiler is set to pdfLaTeX.
4. Click 'Recompile'.
