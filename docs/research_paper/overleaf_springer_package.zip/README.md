# Springer Nature LaTeX Overleaf Package
This package contains the complete, self-contained Springer Nature manuscript for:
"Scale-Adaptive Document Conditioning and Gated CNN--Attention--BiLSTM Recognition for Multi-Dataset Offline Handwritten Text Recognition"
Author: A. Venkata Balaji (Registration No: 23BCE20336)
Affiliation: School of Computer Science and Engineering, Vellore Institute of Technology (VIT), Vellore, India

## How to Compile on Overleaf:
1. Upload this zip file directly into Overleaf (New Project -> Upload Project).
2. Set compiler to pdfLaTeX.
3. Overleaf will automatically detect `main.tex` as the root document. Alternatively, select `paper_springer.tex` or `main_standalone.tex`.
4. Click 'Recompile'.
