# Springer Nature LaTeX Overleaf Package
This package contains the complete, self-contained Springer Nature manuscript for:
'Scale-Adaptive Document Conditioning and Multi-Head Gated Convolutional Networks for Multi-Dataset Handwritten Text Recognition Without Pretrained Foundation Models'
Author: A. Venkata Balaji (Registration No: 23BCE20336)
Affiliation: School of Computer Science and Engineering, Vellore Institute of Technology (VIT), Vellore, India

## How to Compile on Overleaf:
1. Upload this zip file directly into Overleaf (New Project -> Upload Project).
2. Overleaf will automatically detect main.tex as the root document.
3. Ensure compiler is set to pdfLaTeX.
4. Click 'Recompile'.
