# Springer Nature Overleaf Package
Author: A. Venkata Balaji (Reg No: 23BCE20336)
VIT University, India

## How to Compile on Overleaf in 10 Seconds:
### Option 1: Upload ZIP (Recommended)
1. On Overleaf, click "New Project" -> "Upload Project".
2. Select this ZIP file (`overleaf_springer_package.zip`).
3. Overleaf automatically compiles `main.tex` using the included official `sn-jnl.cls` and Springer formatting.
4. Output: Ready-to-publish 2-column Springer Nature research paper PDF!

### Option 2: Standalone Blank Project
If you already have a blank Overleaf project:
1. Open `main_standalone.tex` in a text editor.
2. Paste the entire content into `main.tex` in your Overleaf project.
3. Click "Recompile". It has ZERO missing `.cls` errors because it uses standard pre-installed classes!
